"""Row 74 probes: raft_optical_flow_colab.ipynb @ 9e8462e (CPU-only direct execution, labelled).

Run with CUDA_VISIBLE_DEVICES=-1, an env equal to the notebook PINS
(torch 2.14.0+cpu, torchvision 0.29.0+cpu, numpy 2.5.3, pillow 11.3.0, safetensors 0.8.0), cwd = scratch dir.
The install cell is skipped through its own DIMER_NOTEBOOK_CI_PREINSTALLED=1 switch.
Usage: python run_probes.py <path-to-notebook> <repo-root>
"""
import contextlib, hashlib, io, json, os, re, sys, time
from pathlib import Path

NB, REPO = Path(sys.argv[1]), Path(sys.argv[2])
os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
assert os.environ.get('CUDA_VISIBLE_DEVICES') == '-1'
nb = json.loads(NB.read_text(encoding='utf-8'))
cells = nb['cells']
code = {i: ''.join(c['source']) for i, c in enumerate(cells) if c['cell_type'] == 'code'}
md = {i: ''.join(c['source']) for i, c in enumerate(cells) if c['cell_type'] == 'markdown'}
PHASE = os.environ.get('PROBE_PHASE', 'all')  # 'reuse' = default path + BYOD only, merged into results.json
PRIOR = json.loads(Path('results.json').read_text(encoding='utf-8')) if PHASE == 'reuse' and Path('results.json').exists() else {}
R = {'basis': 'direct execution, local CPU (no GPU), Windows, Python %s; not a Colab/Kaggle run' % sys.version.split()[0]}


def save():
    Path('results.json').write_text(json.dumps(R, indent=2, default=str), encoding='utf-8')


# ---- S: static probes
S = {'n_cells': len(cells), 'code_cells': sorted(code), 'compile_errors': []}
for i, src in code.items():
    try:
        compile(src, f'cell{i}', 'exec')
    except SyntaxError as e:
        S['compile_errors'].append([i, str(e)])
S['metadata_dimer'] = nb['metadata'].get('dimer')
S['install_into_kernel'] = 'pip' in code[3] and 'Restart the runtime' in code[3]
S['uses_uv'] = any('uv pip' in s or 'uv venv' in s for s in code.values())
S['google_colab_upload_only'] = 'from google.colab import files' in code[29] and 'ModuleNotFoundError' not in code[29]
S['adapter_created_cell'] = [i for i, s in code.items() if 'adapter = RaftPipeline.from_pretrained' in s]
S['finetune_cell'] = [i for i, s in code.items() if 'adapter.finetune(' in s]
S['rerun_guidance_in_markdown'] = [i for i, s in md.items() if re.search(r'rerun|re-run|run again', s, re.I)]
patterns = {
    'predict': r'predict (first|before)|before you run|what do you expect|make a prediction',
    'checkpoint_question': r'checkpoint:|check your understanding|\?\s*$',
    'exercise': r'exercise|your turn',
    'glossary': r'glossary',
    'troubleshooting': r'troubleshoot',
    'roadmap': r'roadmap|in this notebook you will',
    'what_to_look_for': r'what to look for',
    'try_next': r'try next',
    'infrastructure_label': r'infrastructure|you can skip|optional reading',
}
S['guided_layer_hits'] = {k: [i for i, s in md.items() if re.search(p, s, re.I | re.M)] for k, p in patterns.items()}
S['hardcoded_counts_in_markdown'] = {i: re.findall(r'75%, 30 pairs|10 synthetic pairs|10 rendered pairs|25%, 10 pairs', s)
                                     for i, s in md.items() if re.search(r'30 pairs|10 (synthetic |rendered )?pairs', s)}
S['runtime_claim'] = re.findall(r'Runtimes are not measured in this revision\.', md[1])
S['spec_declared'] = (S['metadata_dimer'] or {}).get('notebook_spec')
S['byod_min_records_doc'] = re.findall(r'at least \d+ records and at most [\d,]+', md[28])
src_dir = REPO / 'src' / 'raft_optical_flow_pipeline'
S['module_sha256'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(src_dir.glob('*.py'))}
R['static'] = S
if PRIOR:
    R['phase_note'] = 'active section carried from the first full run; default + reuse re-run after fixing the probe path-substitution bug'
save()

# ---- D: default path, every code cell in order
ns = {'__name__': '__main__'}
D = {'cells': {}}
t_all = time.time()


def run(i, src=None):
    buf = io.StringIO()
    t = time.time()
    ok, err = True, None
    with contextlib.redirect_stdout(buf):
        try:
            exec(compile(src or code[i], f'cell{i}', 'exec'), ns)
        except BaseException as e:  # noqa: BLE001 - record every failure
            ok, err = False, f'{type(e).__name__}: {e}'
    return {'ok': ok, 'error': err, 'seconds': round(time.time() - t, 2), 'stdout_tail': buf.getvalue()[-1500:]}


for i in sorted(code):
    D['cells'][i] = run(i)
    R['default'] = D
    save()
    if not D['cells'][i]['ok']:
        break
D['wall_s'] = round(time.time() - t_all, 1)
D['all_ok'] = all(c['ok'] for c in D['cells'].values()) and len(D['cells']) == len(code)
if D['all_ok']:
    D['demo_epe'] = ns['demo_report']['metrics']['epe']
    D['demo_zero_epe'] = ns['zero_row']['epe']
    D['iteration_sweep'] = ns['iteration_sweep']
    D['degenerate'] = ns['degenerate']
    D['baseline_epe'] = ns['baseline']['epe']
    D['adapted_epe'] = ns['adapted']['epe']
    D['zero_epe_heldout'] = ns['baseline']['zero_flow_baseline']['epe']
    D['epoch_losses'] = ns['run']['epoch_losses']
    D['trainable'] = [ns['run']['trainable_parameters'], ns['run']['total_parameters']]
    D['new_data'] = ns['new_data_rows']
    D['reload_check'] = ns['reload_check']
    D['device'] = ns['pipe'].device
    D['outputs'] = sorted(p.name for p in Path('outputs').iterdir() if p.is_file())
R['default'] = D
save()

# ---- A: active learning: the notebook's "Try next" (FREEZE_ENCODERS=False), rerunning only cells 19 and 21
A = PRIOR.get('active', {})
if D['all_ok'] and PHASE != 'reuse':
    import torch
    snap = {k: v.detach().clone() for k, v in ns['adapter'].model.state_dict().items()}
    pre = ns['pipe'].model.state_dict()
    upd = [k for k in snap if k.startswith('update_block') and snap[k].dtype.is_floating_point]
    A['adapter_already_adapted_before_rerun'] = ns['adapter'].adapted
    A['rerun_start_weights_differ_from_pretrained'] = any(not torch.equal(snap[k], pre[k].to(snap[k].device)) for k in upd)
    src19 = code[19].replace('FREEZE_ENCODERS = True', 'FREEZE_ENCODERS = False')
    A['cell19_unfrozen_no_reset'] = run(19, src=src19)
    A['cell21_after_no_reset'] = run(21)
    A['adapted_epe_stacked'] = ns['adapted']['epe']
    A['pretrained_column_from_cell17'] = ns['baseline']['epe']
    A['note'] = ('cell 19 calls adapter.finetune on the object built in cell 17; rerunning 19 without 17 continues '
                 'from already-adapted weights (3 + 3 epochs), and the pretrained column still comes from cell 17')
    A['reset_cell17'] = run(17)
    A['reset_cell19_unfrozen'] = run(19, src=src19)
    A['reset_cell21'] = run(21)
    A['adapted_epe_reset_unfrozen'] = ns['adapted']['epe']
    A['trainable_unfrozen'] = ns['run']['trainable_parameters']
R['active'] = A
save()

# ---- B: reuse / recovery: BYOD branches
B = {}
if D['all_ok']:
    from PIL import Image
    write_flo, moving_shapes_pair = ns['write_flo'], ns['moving_shapes_pair']

    def make_dir(name, n, size=(136, 136), crop=None):
        d = Path('byod_probe') / name
        d.mkdir(parents=True, exist_ok=True)
        entries = []
        for k in range(n):
            r = moving_shapes_pair(500 + k, size=size)
            im1, im2, fl, va = r['image1'], r['image2'], r['flow'], r['valid']
            if crop:  # frames whose sides are not multiples of 8
                w, h = crop
                im1, im2, fl, va = im1.crop((0, 0, w, h)), im2.crop((0, 0, w, h)), fl[:h, :w], va[:h, :w]
            im1.save(d / f'f{k}_1.png')
            im2.save(d / f'f{k}_2.png')
            write_flo(d / f'f{k}.flo', fl)
            Image.fromarray((va * 255).astype('uint8')).save(d / f'f{k}_valid.png')
            entries.append({'frame1': f'f{k}_1.png', 'frame2': f'f{k}_2.png', 'flow': f'f{k}.flo', 'valid': f'f{k}_valid.png'})
        (d / 'pairs.json').write_text(json.dumps(entries))
        return d

    def byod(**kw):
        s = code[29]
        for k, v in kw.items():
            s = re.sub(rf'^{k} = .*$', lambda _m, k=k, v=v: f'{k} = {v!r}  # probe', s, count=1, flags=re.M)
        return run(29, src=s)

    B['dataset_4_records_130x133'] = byod(USE_BYOD_DATASET=True, BYOD_DATASET_DIR=str(make_dir('ok4', 4, crop=(130, 133))))
    B['dataset_2_records_documented_minimum'] = byod(USE_BYOD_DATASET=True, BYOD_DATASET_DIR=str(make_dir('ok2', 2, size=(128, 128))))
    B['dataset_1_record'] = byod(USE_BYOD_DATASET=True, BYOD_DATASET_DIR=str(make_dir('one', 1, size=(128, 128))))
    bad = Path('byod_probe/bad')
    bad.mkdir(parents=True, exist_ok=True)
    (bad / 'pairs.json').write_text(json.dumps([{'frame1': 'a.png', 'frame2': 'b.png'}]))
    B['dataset_incompatible_pairs_json'] = byod(USE_BYOD_DATASET=True, BYOD_DATASET_DIR=str(bad))
    esc = Path('byod_probe/escape')
    esc.mkdir(parents=True, exist_ok=True)
    (esc / 'pairs.json').write_text(json.dumps([{'frame1': '../ok2/f0_1.png', 'frame2': 'b.png', 'flow': 'c.flo'}] * 2))
    B['dataset_path_escape'] = byod(USE_BYOD_DATASET=True, BYOD_DATASET_DIR=str(esc))
    r = moving_shapes_pair(77, size=(320, 200))
    Path('byod_probe/pair').mkdir(parents=True, exist_ok=True)
    r['image1'].save('byod_probe/pair/a.png')
    r['image2'].save('byod_probe/pair/b.png')
    B['pair_paths_320x200'] = byod(USE_BYOD_IMAGE=True, BYOD_IMAGE1_PATH='byod_probe/pair/a.png', BYOD_IMAGE2_PATH='byod_probe/pair/b.png')
    Image.new('RGB', (100, 100)).save('byod_probe/pair/small1.png')
    Image.new('RGB', (100, 100)).save('byod_probe/pair/small2.png')
    B['pair_too_small_100px'] = byod(USE_BYOD_IMAGE=True, BYOD_IMAGE1_PATH='byod_probe/pair/small1.png', BYOD_IMAGE2_PATH='byod_probe/pair/small2.png')
    B['pair_upload_without_colab'] = byod(USE_BYOD_IMAGE=True)
    B['outputs_after_byod'] = sorted(p.name for p in Path('outputs').iterdir() if p.is_file())
    B['result_json_mentions_byod'] = 'byod' in Path('outputs/raft_optical_flow_result.json').read_text(encoding='utf-8').lower()
R['reuse'] = B
R['total_wall_s'] = round(time.time() - t_all, 1)
save()
print(json.dumps({k: v for k, v in R.items() if k != 'static'}, default=str)[:8000])
